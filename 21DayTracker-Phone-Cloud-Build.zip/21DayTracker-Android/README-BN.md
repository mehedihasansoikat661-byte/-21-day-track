# 21-Day Tracker — Android project (phone-only cloud build)

এই প্রজেক্টটি আপনার দেওয়া HTML দিয়ে Android WebView অ্যাপ তৈরি করে। কম্পিউটার ছাড়াই GitHub Actions দিয়ে APK বানানো যাবে।

## ফোন থেকে APK বানানোর ধাপ

1. ZIP ফাইলটি ফোনে ডাউনলোড করে Extract করুন।
2. Chrome-এ https://github.com খুলে একটি অ্যাকাউন্টে Sign in করুন।
3. `New repository` তৈরি করুন; নাম দিন `21-day-tracker`, Public বা Private যেকোনোটি।
4. নতুন repository-তে `Add file` → `Upload files` চাপুন।
5. Extract করা `21DayTracker-Android` ফোল্ডারের ভেতরের সব ফাইল ও `.github` ফোল্ডারসহ আপলোড করুন। খেয়াল রাখবেন, `settings.gradle.kts` যেন repository-র একদম root-এ থাকে; পুরো parent folder-টি এক স্তর বেশি nested হয়ে যেন না যায়।
6. `Commit changes` চাপুন।
7. Repository-র `Actions` tab খুলুন। `Build 21-Day Tracker APK` workflow নির্বাচন করে `Run workflow` চাপুন।
8. Build শেষ হলে ওই run-এর পেজে `Artifacts` অংশ থেকে `21-Day-Tracker-APK` ডাউনলোড করুন।
9. ZIP artifact Extract করে `app-debug.apk` ফাইলে চাপুন। Android চাইলে এই উৎস থেকে Install করার অনুমতি দিন।

## নোট

- প্রথমবার build করতে কয়েক মিনিট লাগতে পারে এবং ইন্টারনেট লাগবে।
- এই ZIP-এ workflow-সহ project source আছে, compiled APK নেই।
- HTML-এর CDN লাইব্রেরি/ফন্ট লোডের জন্য অ্যাপ চালানোর সময়ও ইন্টারনেট প্রয়োজন।
- অ্যাপের ট্র্যাকার ডেটা এই ফোনের WebView localStorage-এ থাকে। অ্যাপের ডেটা মুছে ফেললে বা অ্যাপ আনইনস্টল করলে ডেটা হারাতে পারেন।
